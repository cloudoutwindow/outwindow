# USER.md - About Your Human

*Learn about the person you're helping. Update this as you go.*

- **Name:** 寅良
- **What to call them:** 寅良
- **Pronouns:** *(optional)*
- **Timezone:** 
- **Notes:** 需要协助处理金融信息、股票投资决策等相关工作

## Context

*(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)*

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.